/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.1.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QLineEdit *searchBar;
    QTableWidget *productTable;
    QFrame *customerButtonsFrame;
    QVBoxLayout *customerButtonsLayout;
    QPushButton *addToCartButton;
    QPushButton *viewCartButton;
    QPushButton *removeProductFromCartButton;
    QPushButton *applyDiscountButton;
    QPushButton *applyPromoCodeButton;
    QPushButton *finalizeOrderButton;
    QFrame *sellerButtonsFrame;
    QVBoxLayout *sellerButtonsLayout;
    QPushButton *addProductButton;
    QPushButton *editProductButton;
    QPushButton *removeProductButton;
    QPushButton *viewOrdersButton;
    QFrame *footerFrame;
    QHBoxLayout *footerLayout;
    QLabel *footerLabel;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(800, 600);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        centralWidget->setStyleSheet(QLatin1String("\n"
"     QWidget {\n"
"      background-color:rgb(221, 221, 221);\n"
"      border-radius: 10px;\n"
"      padding: 20px;\n"
"     }\n"
"    "));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        searchBar = new QLineEdit(centralWidget);
        searchBar->setObjectName(QStringLiteral("searchBar"));
        searchBar->setStyleSheet(QLatin1String("\n"
"        QLineEdit {\n"
"         background-color:rgb(170, 145, 145);\n"
"         border: 1px solid #DDD;\n"
"         padding: 10px;\n"
"         border-radius: 5px;\n"
"         font-size: 14px;\n"
"        }\n"
"        QLineEdit:focus {\n"
"         border: 1px solidrgb(168, 245, 242);\n"
"         box-shadow: 0 0 5px rgba(103, 123, 122, 0.6);\n"
"        }\n"
"       "));

        verticalLayout->addWidget(searchBar);

        productTable = new QTableWidget(centralWidget);
        productTable->setObjectName(QStringLiteral("productTable"));
        productTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
        productTable->setSelectionMode(QAbstractItemView::SingleSelection);
        productTable->setSelectionBehavior(QAbstractItemView::SelectRows);
        productTable->setColumnCount(5);
        productTable->setStyleSheet(QLatin1String("\n"
"        QTableWidget {\n"
"         background-color: #FFFFFF;\n"
"         color: #333333;\n"
"         border: 1px solid #DDD;\n"
"         font-size: 14px;\n"
"         border-radius: 5px;\n"
"        }\n"
"        QTableWidget::item {\n"
"         padding: 8px;\n"
"         border-bottom: 1px solid #EEE;\n"
"        }\n"
"        QTableWidget::item:selected {\n"
"         background-color: #D9E6F3;\n"
"         color: #1D60A3;\n"
"        }\n"
"        QTableWidget::horizontalHeader {\n"
"         background-color: #F8F8F8;\n"
"         color: #555;\n"
"         padding: 8px;\n"
"         border-bottom: 1px solid #DDD;\n"
"        }\n"
"       "));

        verticalLayout->addWidget(productTable);

        customerButtonsFrame = new QFrame(centralWidget);
        customerButtonsFrame->setObjectName(QStringLiteral("customerButtonsFrame"));
        customerButtonsFrame->setStyleSheet(QLatin1String("\n"
"        QFrame {\n"
"         background-color: #EAF4F4;\n"
"         border-radius: 10px;\n"
"         padding: 15px;\n"
"         margin-bottom: 20px;\n"
"        }\n"
"        QPushButton {\n"
"         background: #5C8D8B;\n"
"         color: white;\n"
"         border-radius: 10px;\n"
"         padding: 14px 22px;\n"
"         font-size: 16px;\n"
"         border: none;\n"
"         transition: all 0.3s ease;\n"
"         box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);\n"
"        }\n"
"        QPushButton:hover {\n"
"         background: #4A7672;\n"
"         transform: scale(1.05);\n"
"         box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);\n"
"        }\n"
"        QPushButton:pressed {\n"
"         background: #3B615E;\n"
"         transform: scale(0.98);\n"
"         box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);\n"
"        }\n"
"       "));
        customerButtonsLayout = new QVBoxLayout(customerButtonsFrame);
        customerButtonsLayout->setSpacing(6);
        customerButtonsLayout->setContentsMargins(11, 11, 11, 11);
        customerButtonsLayout->setObjectName(QStringLiteral("customerButtonsLayout"));
        addToCartButton = new QPushButton(customerButtonsFrame);
        addToCartButton->setObjectName(QStringLiteral("addToCartButton"));

        customerButtonsLayout->addWidget(addToCartButton);

        viewCartButton = new QPushButton(customerButtonsFrame);
        viewCartButton->setObjectName(QStringLiteral("viewCartButton"));

        customerButtonsLayout->addWidget(viewCartButton);

        removeProductFromCartButton = new QPushButton(customerButtonsFrame);
        removeProductFromCartButton->setObjectName(QStringLiteral("removeProductFromCartButton"));

        customerButtonsLayout->addWidget(removeProductFromCartButton);

        applyDiscountButton = new QPushButton(customerButtonsFrame);
        applyDiscountButton->setObjectName(QStringLiteral("applyDiscountButton"));

        customerButtonsLayout->addWidget(applyDiscountButton);

        applyPromoCodeButton = new QPushButton(customerButtonsFrame);
        applyPromoCodeButton->setObjectName(QStringLiteral("applyPromoCodeButton"));

        customerButtonsLayout->addWidget(applyPromoCodeButton);

        finalizeOrderButton = new QPushButton(customerButtonsFrame);
        finalizeOrderButton->setObjectName(QStringLiteral("finalizeOrderButton"));

        customerButtonsLayout->addWidget(finalizeOrderButton);


        verticalLayout->addWidget(customerButtonsFrame);

        sellerButtonsFrame = new QFrame(centralWidget);
        sellerButtonsFrame->setObjectName(QStringLiteral("sellerButtonsFrame"));
        sellerButtonsFrame->setStyleSheet(QLatin1String("\n"
"        QFrame {\n"
"         background-color:rgb(255, 239, 190);\n"
"         border-radius: 10px;\n"
"         padding: 15px;\n"
"         margin-bottom: 20px;\n"
"        }\n"
"        QPushButton {\n"
"         background:rgb(254, 190, 88);\n"
"         color: white;\n"
"         border-radius: 10px;\n"
"         padding: 14px 22px;\n"
"         font-size: 16px;\n"
"         border: none;\n"
"         transition: all 0.3s ease;\n"
"         box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);\n"
"        }\n"
"        QPushButton:hover {\n"
"         background: #E67E22;\n"
"         transform: scale(1.05);\n"
"         box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);\n"
"        }\n"
"        QPushButton:pressed {\n"
"         background: #D35400;\n"
"         transform: scale(0.98);\n"
"         box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);\n"
"        }\n"
"       "));
        sellerButtonsLayout = new QVBoxLayout(sellerButtonsFrame);
        sellerButtonsLayout->setSpacing(6);
        sellerButtonsLayout->setContentsMargins(11, 11, 11, 11);
        sellerButtonsLayout->setObjectName(QStringLiteral("sellerButtonsLayout"));
        addProductButton = new QPushButton(sellerButtonsFrame);
        addProductButton->setObjectName(QStringLiteral("addProductButton"));

        sellerButtonsLayout->addWidget(addProductButton);

        editProductButton = new QPushButton(sellerButtonsFrame);
        editProductButton->setObjectName(QStringLiteral("editProductButton"));

        sellerButtonsLayout->addWidget(editProductButton);

        removeProductButton = new QPushButton(sellerButtonsFrame);
        removeProductButton->setObjectName(QStringLiteral("removeProductButton"));

        sellerButtonsLayout->addWidget(removeProductButton);

        viewOrdersButton = new QPushButton(sellerButtonsFrame);
        viewOrdersButton->setObjectName(QStringLiteral("viewOrdersButton"));

        sellerButtonsLayout->addWidget(viewOrdersButton);


        verticalLayout->addWidget(sellerButtonsFrame);

        footerFrame = new QFrame(centralWidget);
        footerFrame->setObjectName(QStringLiteral("footerFrame"));
        footerFrame->setStyleSheet(QLatin1String("\n"
"        QFrame {\n"
"         background-color: #F0F0F0;\n"
"         border-radius: 10px;\n"
"         padding: 10px;\n"
"         text-align: center;\n"
"        }\n"
"        QLabel {\n"
"         font-size: 12px;\n"
"         color: #777;\n"
"        }\n"
"       "));
        footerLayout = new QHBoxLayout(footerFrame);
        footerLayout->setSpacing(6);
        footerLayout->setContentsMargins(11, 11, 11, 11);
        footerLayout->setObjectName(QStringLiteral("footerLayout"));
        footerLabel = new QLabel(footerFrame);
        footerLabel->setObjectName(QStringLiteral("footerLabel"));

        footerLayout->addWidget(footerLabel);


        verticalLayout->addWidget(footerFrame);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 800, 26));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Advanced Online Store Simulation", 0));
        searchBar->setPlaceholderText(QApplication::translate("MainWindow", "Note:", 0));
        productTable->setProperty("horizontalHeaderLabels", QVariant(QStringList()
            << QApplication::translate("MainWindow", "Name", 0)
            << QApplication::translate("MainWindow", "Price", 0)
            << QApplication::translate("MainWindow", "Stock", 0)
            << QApplication::translate("MainWindow", "Description", 0)
            << QApplication::translate("MainWindow", "Quantity", 0)));
        addToCartButton->setText(QApplication::translate("MainWindow", "Add to Cart", 0));
        viewCartButton->setText(QApplication::translate("MainWindow", "View Cart", 0));
        removeProductFromCartButton->setText(QApplication::translate("MainWindow", "Remove from Cart", 0));
        applyDiscountButton->setText(QApplication::translate("MainWindow", "Apply Discount", 0));
        applyPromoCodeButton->setText(QApplication::translate("MainWindow", "Apply PromoCode", 0));
        finalizeOrderButton->setText(QApplication::translate("MainWindow", "Finalize Order", 0));
        addProductButton->setText(QApplication::translate("MainWindow", "Add Product", 0));
        editProductButton->setText(QApplication::translate("MainWindow", "Edit Product", 0));
        removeProductButton->setText(QApplication::translate("MainWindow", "Remove Product", 0));
        viewOrdersButton->setText(QApplication::translate("MainWindow", "View Orders", 0));
        footerLabel->setText(QApplication::translate("MainWindow", "Advanced Online Store Simulation", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H

<?xml version="1.0" encoding="UTF-8"?>
<ui version="4.0">
 <class>MainWindow</class>
 <widget class="QMainWindow" name="MainWindow">
  <property name="geometry">
   <rect>
    <x>0</x>
    <y>0</y>
    <width>800</width>
    <height>600</height>
   </rect>
  </property>
  <property name="windowTitle">
   <string>Advanced Online Store Simulation</string>
  </property>
  <widget class="QWidget" name="centralWidget">
   <layout class="QVBoxLayout" name="verticalLayout">
    
    <!-- Product Table -->
    <item>
     <widget class="QTableWidget" name="productTable">
      <property name="editTriggers">
       <set>QAbstractItemView::NoEditTriggers</set>
      </property>
      <property name="selectionMode">
       <enum>QAbstractItemView::SingleSelection</enum>
      </property>
      <property name="selectionBehavior">
       <enum>QAbstractItemView::SelectRows</enum>
      </property>
      <property name="columnCount">
       <number>5</number> <!-- Added one more column for quantity -->
      </property>
      <property name="horizontalHeaderLabels" stdset="0">
       <stringlist>
        <string>Name</string>
        <string>Price</string>
        <string>Stock</string>
        <string>Description</string>
        <string>Quantity</string> <!-- Quantity Column -->
       </stringlist>
      </property>
      <attribute name="horizontalHeaderVisible">
       <bool>false</bool>
      </attribute>
      <attribute name="verticalHeaderVisible">
       <bool>false</bool>
      </attribute>
      <column/>
      <column/>
      <column/>
      <column/>
      <column/> <!-- Quantity Column -->
     </widget>
    </item>

    <!-- Quantity Selection Box -->
    <item>
     <widget class="QSpinBox" name="quantitySpinBox">
      <property name="minimum">
       <number>1</number>
      </property>
      <property name="maximum">
       <number>100</number>
      </property>
      <property name="value">
       <number>1</number>
      </property>
      <property name="prefix">
       <string>Quantity: </string>
      </property>
     </widget>
    </item>
    
    <!-- Buttons -->
    <item>
     <widget class="QPushButton" name="addToCartButton">
      <property name="text">
       <string>Add to Cart</string>
      </property>
     </widget>
    </item>

    <!-- View Cart Button -->
    <item>
     <widget class="QPushButton" name="viewCartButton">
      <property name="text">
       <string>View Cart</string>
      </property>
     </widget>
    </item>

    <!-- Apply Discount Button -->
    <item>
     <widget class="QPushButton" name="applyDiscountButton">
      <property name="text">
       <string>Apply Discount</string>
      </property>
     </widget>
    </item>

    <!-- Finalize Order Button -->
    <item>
     <widget class="QPushButton" name="finalizeOrderButton">
      <property name="text">
       <string>Finalize Order</string>
      </property>
     </widget>
    </item>

    <!-- Inventory Management Buttons -->
    <item>
     <widget class="QPushButton" name="addProductButton">
      <property name="text">
       <string>Add Product</string>
      </property>
     </widget>
    </item>

    <item>
     <widget class="QPushButton" name="editProductButton">
      <property name="text">
       <string>Edit Product</string>
      </property>
     </widget>
    </item>

    <item>
     <widget class="QPushButton" name="removeProductButton">
      <property name="text">
       <string>Remove Product</string>
      </property>
     </widget>
    </item>

    <!-- Transaction History -->
    <item>
     <widget class="QPushButton" name="viewOrdersButton">
      <property name="text">
       <string>View Orders</string>
      </property>
     </widget>
    </item>
   </layout>
  </widget>
  <widget class="QMenuBar" name="menuBar">
   <property name="geometry">
    <rect>
     <x>0</x>
     <y>0</y>
     <width>800</width>
     <height>26</height>
    </rect>
   </property>
  </widget>
  <widget class="QToolBar" name="mainToolBar">
   <attribute name="toolBarArea">
    <enum>TopToolBarArea</enum>
   </attribute>
   <attribute name="toolBarBreak">
    <bool>false</bool>
   </attribute>
  </widget>
  <widget class="QStatusBar" name="statusBar"/>
 </widget>
 <layoutdefault spacing="6" margin="11"/>
 <resources/>
 <connections/>
</ui>
